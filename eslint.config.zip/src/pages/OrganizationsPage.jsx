import React from 'react';
import SearchIcon from '../assets/search-icon.svg';
// استدعاء السايد بار
import Sidebar from '../components/Sidebar'; 

const OrganizationsPage = () => {
  const organizations = [
    { name: "Egyptian Red Crescent", email: "erc@egyptianrc.org", status: "Blocked" },
    { name: "Tunisian Red Crescent", email: "hilal.ahmar@planet.tn", status: "Blocked" },
    { name: "Algerian Red Crescent", email: "communication@cra.dz", status: "Active" },
    { name: "Croissant-Rouge marocain", email: "crm@menara.ma", status: "Active" },
    { name: "Libyan Red Crescent", email: "info@lrc.org.ly", status: "Active" },
  ];

  return (
    <div className="flex bg-[#F3F4F6] min-h-screen font-sans">
      {/* 1. السايد بار يظهر هنا */}
      <Sidebar />

      {/* 2. المحتوى الرئيسي مع الإزاحة المطلوبة */}
      <div className="flex-1 ml-[260px] p-8 text-left">
        <div className="max-w-[1200px] mx-auto">
          
          <h2 className="text-2xl font-bold text-[#49987A] mb-8">Organizations</h2>

          {/* السيرش بوكس */}
          <div className="relative mb-6" style={{ width: '1044px', height: '58px' }}>
            <span className="absolute left-5 top-1/2 -translate-y-1/2">
              <img src={SearchIcon} alt="search" className="w-6 h-6 opacity-40" />
            </span>
            <input 
              type="text" 
              placeholder="Search" 
              className="w-full h-full bg-white pl-14 pr-6 rounded-lg text-lg outline-none border border-gray-300 shadow-sm focus:border-[#49987A] transition-all"
            />
          </div>

          {/* الجدول */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200" style={{ width: '1044px' }}>
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#D4CDCD] text-gray-800 font-bold">
                <tr>
                  <th className="px-6 py-4 border-r border-gray-300">Name</th>
                  <th className="px-6 py-4 border-r border-gray-300">Email</th>
                  <th className="px-6 py-4 border-r border-gray-300">Status</th>
                  <th className="px-6 py-4 text-center">Action</th>
                </tr>
              </thead>

              <tbody className="text-black">
                {organizations.map((org, i) => (
                  <tr key={i} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-bold">{org.name}</td>
                    <td className="px-6 py-4 text-sm font-bold">{org.email}</td>
                    <td className="px-6 py-4">
                      <span className={`px-4 py-1 rounded text-white text-[10px] font-bold ${org.status === 'Blocked' ? 'bg-[#E09A9A]' : 'bg-[#49987A]'}`}>
                        {org.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center flex justify-center gap-2">
                      <button className="bg-[#BDBDBD] text-white px-3 py-1 rounded text-[10px] font-bold w-[93px]">
                        Unblock
                      </button>
                      <button className="bg-[#E09A9A] text-white px-3 py-1 rounded text-[10px] font-bold w-[93px]">
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
};

export default OrganizationsPage;
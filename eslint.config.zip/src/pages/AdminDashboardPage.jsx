import React from 'react';
// الـ Imports للأيقونات
import OrgIcon from '../assets/org-icon.svg';
import UsersIcon from '../assets/users-icon.svg';
import PendingIcon from '../assets/pending-icon.svg';

// استدعاء السايد بار - عدلت المسار ليدخل جوه الفولدر
import Sidebar from '../components/Sidebar'; 

const AdminDashboardPage = () => {
  const organizations = [
    { name: "Egyptian Red Crescent", email: "erc@egyptianrc.org", status: "Blocked" },
    { name: "Tunisian Red Crescent", email: "hilal.ahmar@planet.tn", status: "Blocked" },
    { name: "Algerian Red Crescent", email: "communication@cra.dz", status: "Active" },
    { name: "Croissant-Rouge marocain", email: "crm@menara.ma", status: "Active" },
    { name: "Libyan Red Crescent", email: "info@lrc.org.ly", status: "Active" },
  ];

  const users = [
    { name: "malak khaled", email: "Malakkhaled@gmail.com", phone: "01222334497", status: "Blocked" },
    { name: "Youssef Ahmed", email: "youssefahmed@gmail.com", phone: "01222334497", status: "Blocked" },
    { name: "Hana Hassan", email: "hanahassan@gmail.com", phone: "01222334497", status: "Blocked" },
    { name: "Hana Hassan", email: "hanahassan@gmail.com", phone: "01222334497", status: "Active" },
  ];

  return (
    <div className="flex bg-[#F3F4F6] min-h-screen font-sans">
      {/* ظهور السايد بار */}
      <Sidebar />

      {/* المحتوى الرئيسي مع الإزاحة عشان ميتغطاش بالسايد بار */}
      <div className="flex-1 ml-[260px] p-8">
        <div className="max-w-[1200px] mx-auto">
          <h2 className="text-xl font-bold text-gray-800 mb-6 text-left">Dashboard Admin</h2>

          {/* المربعات الأربعة */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            {[
              { t1: 'Total', t2: 'Organizations', count: '120', icon: OrgIcon },
              { t1: 'Total', t2: 'Users', count: '350', icon: UsersIcon },
              { t1: 'Active', t2: 'Users', count: '120', icon: UsersIcon },
              { t1: 'Pending', t2: 'Approvals', count: '100', icon: PendingIcon }
            ].map((stat, i) => (
              <div key={i} className="bg-[#49987A] h-[151px] rounded-lg shadow-sm text-white p-4 relative flex flex-col items-center justify-center">
                <img src={stat.icon} alt="icon" className="absolute top-3 left-3 w-8 h-8 object-contain" />
                <div className="text-center">
                  <p className="text-[14px] leading-tight font-light">{stat.t1}</p>
                  <p className="text-[18px] font-bold leading-tight mb-2">{stat.t2}</p>
                  <h3 className="text-4xl font-extrabold">{stat.count}</h3>
                </div>
              </div>
            ))}
          </div>

          {/* جدول المنظمات */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-8 border border-gray-200">
            <div className="bg-[#49987A] px-6 py-3 text-white font-bold text-xl">Latest Organizations</div>
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#D4CDCD] text-gray-800 font-bold">
                <tr>
                  <th className="px-6 py-3 border-r border-gray-300">Name</th>
                  <th className="px-6 py-3 border-r border-gray-300">Email</th>
                  <th className="px-6 py-3 border-r border-gray-300">Status</th>
                  <th className="px-6 py-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="text-black">
                {organizations.map((org, i) => (
                  <tr key={i} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-3 text-sm font-bold">{org.name}</td>
                    <td className="px-6 py-3 text-sm font-bold">{org.email}</td>
                    <td className="px-6 py-3">
                      <span className={`px-4 py-1 rounded text-white text-xs font-bold ${org.status === 'Blocked' ? 'bg-[#E09A9A]' : 'bg-[#49987A]'}`}>
                        {org.status}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-center flex justify-center gap-2">
                      <button className="bg-[#BDBDBD] text-white px-3 py-1 rounded text-xs font-bold w-[93px]">Unblock</button>
                      <button className="bg-[#E09A9A] text-white px-3 py-1 rounded text-xs font-bold w-[93px]">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* جدول المستخدمين */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
            <div className="bg-[#49987A] px-6 py-3 text-white font-bold text-xl">Latest Users</div>
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#D4CDCD] text-gray-800 font-bold">
                <tr>
                  <th className="px-6 py-3 border-r border-gray-300">Name</th>
                  <th className="px-6 py-3 border-r border-gray-300">Email</th>
                  <th className="px-6 py-3 border-r border-gray-300">Phone</th>
                  <th className="px-6 py-3 border-r border-gray-300">Status</th>
                  <th className="px-6 py-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="text-black">
                {users.map((user, i) => (
                  <tr key={i} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-3 text-sm font-bold">{user.name}</td>
                    <td className="px-6 py-3 text-sm font-bold">{user.email}</td>
                    <td className="px-6 py-3 text-sm font-bold">{user.phone}</td>
                    <td className="px-6 py-3">
                      <span className={`px-4 py-1 rounded text-white text-xs font-bold ${user.status === 'Blocked' ? 'bg-[#E09A9A]' : 'bg-[#49987A]'}`}>
                        {user.status}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-center flex justify-center gap-2">
                      <button className="bg-[#BDBDBD] text-white px-3 py-1 rounded text-xs font-bold w-[93px]">Unblock</button>
                      <button className="bg-[#E09A9A] text-white px-3 py-1 rounded text-xs font-bold w-[93px]">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
import { useNavigate } from 'react-router-dom';
import { useState } from 'react'; // 1. ضفنا دي عشان نحفظ البيانات
import '../App.css';
import SignIn from '../assets/signin-logo.png'; 

function SignInPage() {
  // 2. عملنا مخزن للإيميل ومخزن للباسورد
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const navigate = useNavigate();

  // 3. الفانكشن اللي بتتأكد من البيانات لما تدوسي على الزرار
  const handleLogin = () => {
    if (email === 'youssif@gmail.com' && password === 'youssif') {
     navigate('/admin-dashboard');
    } else {
      alert('الإيميل أو الباسورد خطأ! جربي تاني');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      {/* Container الأساسي */}
      <div className="bg-white w-full max-w-[1100px] flex overflow-hidden shadow-2xl min-h-[650px] rounded-lg">
        
        {/* الجزء الأبيض (Sign In) */}
        <div className="w-[60%] p-16 flex flex-col justify-center">
          <h1 className="text-[#49987A] text-5xl font-bold mb-12 text-center">
            Sign in to silent link
          </h1>
          
          <div className="space-y-6">
            {/* Input الـ Email */}
            <div className="relative">
              <span className="absolute inset-y-0 left-5 flex items-center text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </span>
              <input 
                type="email" 
                placeholder="Email" 
                value={email} // ربطناه بالمخزن
                onChange={(e) => setEmail(e.target.value)} // تحديث المخزن لما تكتبي
                className="w-full bg-[#E9E9E9] py-5 pl-16 pr-6 rounded-lg outline-none focus:ring-2 focus:ring-[#49987A] text-lg transition-all"
              />
            </div>

            {/* Input الـ Password */}
            <div className="relative">
              <span className="absolute inset-y-0 left-5 flex items-center text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </span>
              <input 
                type="password" 
                placeholder="Password" 
                value={password} // ربطناه بالمخزن
                onChange={(e) => setPassword(e.target.value)} // تحديث المخزن لما تكتبي
                className="w-full bg-[#E9E9E9] py-5 pl-16 pr-6 rounded-lg outline-none focus:ring-2 focus:ring-[#49987A] text-lg transition-all"
              />
            </div>

            {/* زرار الـ Sign In */}
            <div className="pt-6 mt-16 text-center">
              <button 
                onClick={handleLogin} // ناديت على الفانكشن هنا
                className="bg-[#49987A] text-white w-[220px] py-4 rounded-full font-bold text-xl hover:bg-[#3d7f66] transition-colors shadow-lg uppercase tracking-wider"
              >
                SIGN IN
              </button>
            </div>
          </div>
        </div>

        {/* الجزء الأخضر (Hello) */}
        <div className="w-[40%] bg-[#49987A] flex flex-col items-center justify-center text-white p-12 text-center">
          <div className="mb-8">
            <img src={SignIn} alt="Silent Link Logo" className="w-48 h-48 object-contain" />
          </div>
          <h2 className="text-6xl font-bold mb-6 -mt-20 pl-10">Hello</h2>
          <p className="text-2xl font-light opacity-95 leading-relaxed pl-10">
            Enter your personal details
          </p>
        </div>

      </div>
    </div>
  );
}

export default SignInPage;
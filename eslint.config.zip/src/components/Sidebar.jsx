import React from 'react';
import { NavLink } from 'react-router-dom';

// استيراد الأيقونات SVG
import DashboardIcon from '../assets/dashboard-icon.svg';
import OrgIcon from '../assets/org-icon.svg';
import UsersIcon from '../assets/users-icon.svg';
import LogoutIcon from '../assets/logout-icon.svg';
import SettingsIcon from '../assets/setting-icon.svg'; 
import NameIcon from '../assets/name-icon.svg'; 

const Sidebar = () => {
  return (
    <div className="w-[260px] h-screen bg-[#49987A] text-white fixed left-0 top-0 flex flex-col py-8 px-4">
      
      {/* الجزء بتاع البروفايل */}
      <div className="flex items-center gap-4 mb-10 px-4">
        <img src={NameIcon} alt="Profile Icon" className="w-[40px] h-[40px]" />
        <span className="text-lg font-bold">Malak Khaled</span>
      </div>

      {/* القائمة الأساسية */}
      <nav className="flex-1 space-y-2">
        <NavLink
          to="/admin-dashboard"
          className={({ isActive }) =>
            `flex items-center gap-4 px-6 py-3 rounded-lg transition-all ${
              isActive ? 'bg-[#D4CDCD] text-[#2D5A49] font-bold' : 'hover:bg-[#3d8168]'
            }`
          }
        >
          <img src={DashboardIcon} className="w-6 h-6" alt="" />
          <span>Dashboard</span>
        </NavLink>

        <NavLink
          to="/organizations"
          className={({ isActive }) =>
            `flex items-center gap-4 px-6 py-3 rounded-lg transition-all ${
              isActive ? 'bg-[#D4CDCD] text-[#2D5A49] font-bold' : 'hover:bg-[#3d8168]'
            }`
          }
        >
          <img src={OrgIcon} className="w-6 h-6" alt="" />
          <span>Organizations</span>
        </NavLink>

        <NavLink
          to="/users"
          className={({ isActive }) =>
            `flex items-center gap-4 px-6 py-3 rounded-lg transition-all ${
              isActive ? 'bg-[#D4CDCD] text-[#2D5A49] font-bold' : 'hover:bg-[#3d8168]'
            }`
          }
        >
          <img src={UsersIcon} className="w-6 h-6" alt="" />
          <span>Users</span>
        </NavLink>
      </nav>

      {/* الجزء اللي تحت (Settings & Logout) */}
      <div className="border-t border-[#ffffff33] pt-6 space-y-2">
        {/* التعديل هنا: خليناه يروح لـ admin-settings اللي ربطناها في الـ Routes */}
        <NavLink
          to="/admin-settings"
          className={({ isActive }) =>
            `flex items-center gap-4 px-6 py-3 rounded-lg transition-all ${
              isActive ? 'bg-[#D4CDCD] text-[#2D5A49] font-bold' : 'hover:bg-[#3d8168]'
            }`
          }
        >
          <img src={SettingsIcon} className="w-6 h-6" alt="" />
          <span>Settings</span>
        </NavLink>

        <button className="w-full flex items-center gap-4 px-6 py-3 rounded-lg hover:bg-[#3d8168] transition-all text-left">
          <img src={LogoutIcon} className="w-6 h-6" alt="" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
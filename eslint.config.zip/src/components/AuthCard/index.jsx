export { default } from './AuthCard';

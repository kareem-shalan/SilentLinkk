export { default } from './SosManagementTable';

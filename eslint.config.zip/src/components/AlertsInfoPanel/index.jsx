export { default } from './AlertsInfoPanel';

export { default } from './DashboardMapLegend';

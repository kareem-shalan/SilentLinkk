export { default } from './PromoPanel';
